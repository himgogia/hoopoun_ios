//
//  Costant.swift
//  Hoopoun
//
//  Created by vineet patidar on 17/08/17.
//  Copyright © 2017 Ramniwas Patidar. All rights reserved.
//

import UIKit

let kSignupSegueIdentifier = "signupSegueIdentifier"
let kVerifySegueIdentifier = "verifySegueIdentifier"
let kProfileSegueIdentifier = "profileSegueIdentifier"
let kForgotPasswordSegueIdentifier = "forgotPasswordSegueIdentifier"
let kChangePasswordSegueIdentifier = "changePasswordSegueIdentifier"
let kTabbarSegueIdentifier = "tabbarSegueIdentifier"
let kCategoryDetailsIdentifier = "categoryDetailsIdentifier"
let kcategoryOfferIdentifier = "categoryOfferIdentifier"
let kselectLocationSegueIdentifier = "selectLocationSegueIdentifier"
let kfiltersegieIdentifier = "filtersegieIdentifier"
let kcategorySegmentSegueIdentifier = "categorySegmentSegueIdentifier"
let kaddStoreReviewSegueIdentifier = "addStoreReviewSegueIdentifier"


//FONTS

let kFontSFUITextRegular  = "SFUIText-Regular"
let kFontSFUITextRegularBold  = "SFUIText-Bold"
let kFontSFUITextSemibold = "SFUIText-Semibold"
let kFontSFUITextLight  = "SFUIText-Light"
let kFontSFUITextMedium  = "SFUIText-Medium"


let kBaseUrl = "http://staging.hoopoun.com/api/"
// story board id

let krightNowViewController = "rightNowViewController"
let karoundMeViewController  = "aroundMeViewController"
let khotDealViewController  = "hotDealViewController"

let kcategoryFilterViewController  = "categoryFilterViewController"
let klocationFilterViewController = "locationFilterViewController"

let kcategoryDetailsOfferStoryboard = "categoryDetailsOfferStoryboard"
let kcategoryDetailInfoStoryBoard = "categoryDetailInfoStoryBoard"
let kcategoryDetailReviewStoryBoard = "categoryDetailReviewStoryBoard"

let kCategorySegmentStoryBoardID = "CategorySegmentStoryBoardID"


let kUserDefault  =  UserDefaults.standard
let kDefaultColor  = UIColor(red: 50.0/255.0, green:
    191.0/255.0, blue: 204.0/255.0, alpha: 1.0)
let kBlueColor  = UIColor(red: 29.0/255.0, green:
    123.0/255.0, blue: 175.0/255.0, alpha: 1.0)
let kLightBlueColor  = UIColor(red: 49.0/255.0, green:
    201.0/255.0, blue: 207.0/255.0, alpha: 1.0)




//  Device IPHONE
let kIphone_4s : Bool =  (UIScreen.main.bounds.size.height == 480)
let kIphone_5 : Bool =  (UIScreen.main.bounds.size.height == 568)
let kIphone_6 : Bool =  (UIScreen.main.bounds.size.height == 667)
let kIphone_6_Plus : Bool =  (UIScreen.main.bounds.size.height == 736)

let kIphoneWidth = UIScreen.main.bounds.size.width
let kIphoneHeight = UIScreen.main.bounds.size.height


//

let kPayload = "Payload"
let kCode =  "Code"
let kMessage = "Message"



// login

let kloginId  = "loginId"
let kpassword = "password"
let kloginInfo = "loginInfo"



// signup

let kname = "name"
let kmobileNumber = "mobileNumber"
let kregister_type = "register_type"
let ksocialId  = "socialId"
let kstype = "stype"
let kfbId = "fbId"
let kgpId = "gpId"


let kdeviceToken = "deviceToken"
let kdeviceType = "deviceType"
let kdeviceId = "deviceId"
let kSocialLogin = "socialLogin"

let kid = "id"
let kIOS = "IOS"
let kimage = "image"
let kverificationId = "verificationId"
let ktransactionId = "transactionId"
let kemailId = "emailId"
let knewPassword = "newPassword"
let kconfirmPassword = "confirmPassword"
let koldPassword = "oldPassword"


// forgot password

let kforgotPassword = "forgotPassword"
let kchangePassword = "changePassword"


// Offer
let klatitude = "latitude"
let klongitude = "longitude"
let kcity_id = "city_id"
let kcategories_name = "categories_name"
let kcategory_id = "category_id"
let kiconFileName = "iconFileName"
let kst_distance = "st_distance"
let kuserid = "userid"

// near  me

let kofferImage = "offerImage"
let kofferTitle = "offerTitle"
let kofferType  = "offerType"
let kcoupon = "coupon"
let kdayId = "dayId"
let kdescription = "description"
let kdistance = "distance"
let kheads_name = "heads_name"
let kloyalityCard = "loyalityCard"
let koffer_id = "offer_id"
let kratting = "ratting"
let kstoreAddress = "storeAddress"
let kstoreId = "storeId"
let kstore_name = "store_name"
let ksubsubcategories_name = "subsubcategories_name"
let ktages = "tages"
let kterms = "terms"

// ccategories offres

let kcategoryOffersArray = "categoryOffersArray"
let ksort_by = "sort_by"
let kfilter_categories = "filter_categories"
let kfilter_location = "filter_location"
let kcat_id = "cat_id"
let kpage_no = "page_no"
let ksearch_city = "search_city"
let kaddress = "address"
let ksubcategoryId = "subcategoryId"
let kcategoryId = "categoryId"
let ksubcategoryName = "subcategoryName"
let ksubsubCatId = "subsubCatId"
let klocality = "locality"
let kcityName = "cityName"
let klocalityId = "localityId"

// location search
let kpopular_status = "popular_status"

// offers details

let kstore_id = "store_id"
let kstatus = "status"
let kislike =  "islike"

let koffers_timming = "offers_timming"
let koffers_list = "offers_list"
let kdayname = "dayname"
let ktimming = "timming"
let kstore_timming = "store_timming"

// Store Review
let kuserName = "userName"
let kreview = "review"
let kcreated_on = "created_on"
let kuserImage = "userImage"
let krating = "rating"









